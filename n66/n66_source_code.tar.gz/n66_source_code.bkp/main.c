/*
Developer: Thermius
Country: Brazil
Note: I don't speak fluent English but I made an effort to write notes in English to facilitate any modifications to the code. I would like you to help me implement options for the IPv4 header. I tried different ways to implement it but I couldn't.*/
#include "lang.h"
#include <errno.h>
#include <linux/if_packet.h>
#include <linux/if_ether.h>
#include <linux/if_arp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "n66.h"
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <arpa/inet.h> 
#include <stdint.h>
#include <unistd.h>

#define ERROR 0
#define ALERT 1
#define TUTORIAL 2

/*funcitions*/
void  TXT (int, int , int);
void guide ();
void proc_args(int, char*[], char*, char*, char*, char*, char*);

/*global*/
size_t interface_number;	/*receiv ther interface nubmer*/
size_t arp_set;			/*receiv 1 if arp is set*/
size_t ouvir;			/*Mode lissten*/
size_t flood;			/*Mode flood*/
size_t quant = 2;		/*Quant of packets to send*/
size_t tempo = 1;		/*Time of between send packets*/
size_t ip_rand;			/*Mode host_rand*/
size_t protocol_;		/*Protocol type*/
size_t dst_set;			/*IP dst set*/
size_t src_set;			/*IP src set*/
size_t data_set;		/*tcp send set*/
size_t net_bits;		/*Save quant of bits to gerate host rand*/
size_t quant_host;		/*Save quant host genetar to ip hand*/
char *tcp_data;			/*Pointer to data tcp forneced by arg*/
char *net_ip;			/*Pointer to net address if ip rand is set*/
char *ip_dst_arg;		/*Pointer to ip dest by argv*/
char *ip_src_arg; 		/*Pointer to ip src by argv*/
char *p_to_net_bits;		/*Poniter to net bits number argv*/
size_t operation = 0;		/*Sum of mode operation;*/
size_t fake_data;		/*fake data 0*/
size_t fk_data_set;		/*fake data set*/
size_t tam_datagrama;		/*return make_ipv4 datagram lenght*/
int z;				/*for arp frame*/
/*main*/
int main (int argc, char *argv[]) {
	
	/*variables*/
	int soc;						/*socket descriptoor*/
	char datagrama [1600];					/*final datagrama that will be send*/
	size_t retorno;						/*return of sendto*/
	char ip_origem [18];					/*source ip*/
	char ip_destino [18];					/*destination ip*/
	char dados_main [1400];					/*tcp data*/
	char diretorio [40];					/*get diretory of user to read the files */
	char net_ip_main [18];					/*get ip network to make hosts rand*/
	char aux_dir [40];					/*save an copy of diretory /home/<user>/n66*/
	char *data;						/*pointer to end datagram to put the data*/
	memset (datagrama,	0,sizeof(datagrama));
	memset (dados_main,	0,sizeof(dados_main));

	/*variables to read file ipv4_header*/
	size_t tos_;
	size_t id_;
	size_t frag_;
	size_t ttl_;
	size_t check_;

	/*variable tcp and udp*/
	size_t source_;
	size_t dest_;
	size_t seq_;
	size_t ack_seq_;
	size_t doff_;
	size_t fin_;
	size_t syn_;
	size_t rst_;
	size_t psh_;
	size_t ack_;
	size_t urg_;
	size_t window_;
	size_t check_tcp_or_udp;
	size_t urg_ptr_;

	/*processing argv and directory*/
	if (argc < 2) {
		guide();
		exit (0);
	}

	get_home_n66 (diretorio);
	proc_args(argc, argv, diretorio, net_ip_main, ip_origem, ip_destino,dados_main);
	strcpy(aux_dir,diretorio);

	/*open socket*/
	soc = socket (AF_INET,SOCK_RAW,IPPROTO_TCP);
	if (soc ==-1 ) {
		TXT (ERROR,0,1); 
		exit  (0);
	}

	/*resolv sockaddrin*/
	struct sockaddr_in my;
	addr_in (&my,ip_destino);

	/*socket opt hander include*/
	opt_soc(&soc);

	/*read ipv4 file*/
	strcat(diretorio,"/ipv4_header");
	read_ipv4 (diretorio, &tos_, &id_, &frag_, &ttl_, &check_);

	/*protocol*/
	tam_datagrama = make_ipv4 (datagrama,
					5,
					4,
					tos_,	
					id_,
					frag_,
					ttl_,
					protocol_,
					check_,
					ip_origem,
					ip_destino);

	if (arp_set == 0) {	
	switch (protocol_) {

	case 6:

		/*read tcp file*/
		memset(diretorio,0,sizeof(diretorio));
		strcat (diretorio,aux_dir);
		strcat(diretorio,"/tcp_header");

		read_tcp (	diretorio,
				&source_,
				&dest_,
				&seq_,
				&ack_seq_,
				&doff_,
				&fin_,
				&syn_,
				&rst_,
				&psh_,
				&ack_,
				&urg_,
				&window_,
				&check_tcp_or_udp,
				&urg_ptr_);

		/*make tcp packet*/
		make_tcp(	datagrama,
				source_,
			       	dest_,
			       	seq_,
			       	ack_seq_, 
				doff_, 
				fin_, 
				syn_, 
				rst_, 
				psh_, 
				ack_, 
				urg_,
				window_,
			       	check_tcp_or_udp, 
				urg_ptr_, 
				ip_destino,
			       	ip_origem, 
				dados_main,
				/*ipv4 variables*/
				5,
				4,
				tos_,
				id_,
				frag_,
				ttl_,
				protocol_,
				check_);
		
		/*copy data in operation 2 tcp*/
		tam_datagrama = tam_datagrama + strlen (dados_main);

		if (data_set == 1 ) {
			data = (datagrama + tam_datagrama )- strlen (dados_main);
			strcpy(data,dados_main);
		}
	break;
	
	case 17:
		memset(diretorio,0,sizeof(diretorio));
		strcat (diretorio,aux_dir);
		strcat(diretorio,"/udp_header");
		

		read_udp (	diretorio,
			 	 &source_,
				 &dest_,
				 &check_tcp_or_udp);
	
		make_udp(	/*ipv4*/
				datagrama,
				5,
				4,
				tos_,	
				id_,
				frag_,
				ttl_,
				protocol_,
				check_,
				ip_origem,
				ip_destino,
				/*udp*/
				source_,
				dest_,
				check_tcp_or_udp);
		
		/*copy data in operation 2 udp*/
		tam_datagrama = tam_datagrama + strlen (dados_main);

		if (data_set == 1 ) {
			data = (datagrama + tam_datagrama ) - strlen (dados_main);
			strcpy(data,dados_main);
		}	

	break;
		
	}/*end switch protocol*/
	}/*end if set_arp*/
	







/*operation 2 - ip dest and source set*/
if (operation == 2) {

	/*send packet in flood mode*/
	if (flood == 1) {
		TXT(ALERT,0,1);
		TXT(ALERT,1,0);
		printf(": %s\n",ip_destino);
		TXT(ALERT,2,0);
		printf(": %i bytes\n",tam_datagrama);
	while (1) {
		retorno = sendto(soc, datagrama ,tam_datagrama ,0 ,(struct sockaddr*)&my, sizeof(struct sockaddr));
		sleep (tempo);
			
		  }
	} /*end flood mode*/

	



	/*send packet in count mode*/
	while (quant != 0) {
		retorno =  sendto(soc, datagrama ,tam_datagrama ,0 ,(struct sockaddr*)&my, sizeof(struct sockaddr));

		if (retorno == -1) {
			TXT(ERROR,1,0);
			printf("Debug: %i\n",tam_datagrama);
			printf (": %i\n",retorno);
		}
		else { 
			TXT(ALERT,4,0);
			printf(": %s - %i bytes\n",ip_destino,retorno);
		}

		quant --;
		sleep (tempo);
	}/*end normal mode*/

	} /*end operation 2*/

/*operation 3 - rand ip mode*/
if (operation == 3) {	

	
		/*read tcp file*/
		memset(diretorio,0,sizeof(diretorio));
		strcat (diretorio,aux_dir);
		strcat(diretorio,"/tcp_header");
		read_tcp (	diretorio,
				&source_,
				&dest_,
				&seq_,
				&ack_seq_,
				&doff_,
				&fin_,
				&syn_,
				&rst_,
				&psh_,
				&ack_,
				&urg_,
				&window_,
				&check_tcp_or_udp,
				&urg_ptr_);
		
		/*create pointer to change the ip source*/
		struct iphdr *ip_host = (struct iphdr*)datagrama;
		
		/*loop to recreate packet*/ 
		TXT(ALERT,3,1);		
		TXT(ALERT,1,0);
		printf(": %s\n",ip_destino);
		TXT(ALERT,5,0);
		printf(": %i bytes\n",tam_datagrama);
		
		/*copy data in operation 3*/
		tam_datagrama = tam_datagrama + strlen (dados_main);
		if (data_set == 1 ) {
			data = (datagrama + tam_datagrama )- strlen (dados_main);
			strcpy(data,dados_main);
		}
	
		while (1) {
			
		/*gerate host rand*/
		ip_aleatorio (quant_host,	net_ip_main, 	ip_origem);
	
		/*make tcp packet*/
		make_tcp(	datagrama,
				source_,
			       	dest_,
			       	seq_,
			       	ack_seq_, 
				doff_, 
				fin_, 
				syn_, 
				rst_, 
				psh_, 
				ack_, 
				urg_,
				window_,
			       	check_tcp_or_udp, 
				urg_ptr_, 
				ip_destino,
			       	ip_origem, 
				dados_main,
				/*ipv4 variables*/
				5,
				4,
				tos_,
				id_,
				frag_,
				ttl_,
				protocol_,
				check_);		
		
		/*old data code*/
	
		/*send packet*/
		sendto(soc, datagrama ,tam_datagrama ,0 ,(struct sockaddr*)&my, sizeof(struct sockaddr));
		memset(datagrama,0,sizeof(datagrama));
		sleep (tempo);
	}
	} /*end operation 3*/

/*operation 10 - arp*/ 
if (operation == 10) {

	#define TAM6 6
	#define TAM4 4

	int tam;
	memset (datagrama,0,sizeof(datagrama));
	close (soc);
	get_home_n66 (diretorio);
	strcat(diretorio,"/arp_header");

	/*open socket*/
	soc = socket (PF_PACKET,SOCK_RAW,IPPROTO_RAW);
	if (soc < 0) {
		TXT(ERROR,2,1);
		TXT(ERROR,3,0);
		printf(": %i\n",errno);
		exit(0);
	}

	
	/*variables that will receive the read values converted to int*/

	/*ethernet frame*/
	int i_mac_eth_src [TAM6];
	int i_mac_eth_dst [TAM6];
	int i_p_type_eth;
	/*arp frame*/
	int i_h_type_arp;
	int i_p_type_arp;
	int i_h_size_arp;
	int i_p_size_arp;
	int i_op_code;
	int i_mac_arp_src [TAM6];
	int i_ip_arp_src  [TAM4];
	int i_mac_arp_dst [TAM6];
	int i_ip_arp_dst  [TAM4];
	
	{
	/*temporary variables that will read the arp file*/
	/*ethernet frame*/
	char mac_eth_src [20];
	char mac_eth_dst [20];
	char ptype[10];
	/*arp frame*/
	char h_type [10];
	char p_type [10];
	char h_size [11];
	char p_size [11];
	char op_code [11];
	char mac_arp_src [30];
	char ip_arp_src [20];
	char mac_arp_dst [30];
	char ip_arp_dst [20];
	

	read_arp (	diretorio,
			/*ethernet*/
			mac_eth_src,
			mac_eth_dst,
			ptype,
			/*arp*/
			h_type,
			p_type,
			h_size,
			p_size,
			op_code,
			mac_arp_src,
			ip_arp_src,
			mac_arp_dst,
			ip_arp_dst);

		/*For the 'void extract' function to be able to read the file, the character ':' 
		must be at the end of the string as this is the character that the function looks for to start reading and converting the value*/
		char c = ':';
		
		/*removing the \n from the string to concatenate the ':' character*/
		remove_n (mac_eth_src);
		remove_n (mac_eth_dst);
		remove_n (mac_arp_src);
		remove_n (mac_arp_dst);

		strncat (mac_eth_src,	&c,1);
		strncat (mac_eth_dst,	&c,1);
		strncat (mac_arp_dst,	&c,1);
		strncat (mac_arp_src,	&c,1);

		
		extrair (mac_eth_src,	&i_mac_eth_src[0]);
		extrair (mac_eth_dst,	&i_mac_eth_dst[0]);
		extrair (mac_arp_src,	&i_mac_arp_src[0]);
		extrair (mac_arp_dst,	&i_mac_arp_dst[0]);
		
		/*extract the ptype of ethernet frame*/
		strncat (ptype,		&c,1);
		extrair (ptype,		&i_p_type_eth);
	
		/*extract the hardware type of arp frame*/
		strncat (h_type,	&c,1);
		extrair (h_type,	&i_h_type_arp);
	
		/*extract the protocol type of arp frame*/
		strncat (p_type,	&c,1);
		extrair (p_type,	&i_p_type_arp);

		/*extract the protocol size of arp frame */
		strncat (p_size,	&c,1);
		extrair (p_size,	&i_p_size_arp);	
	
		/*extract the mac size of arp frame */
		strncat (h_size,	&c,1);
		extrair (h_size,	&i_h_size_arp);	

		/*extract the op code of arp frame*/
		strncat (op_code,	&c,1);
		extrair (op_code,	&i_op_code);

		/*extract the  \n on ips of arp frame*/
		remove_n (ip_arp_src);
		remove_n (ip_arp_dst);
		
		/*It is necessary to concatenate  '.' character at the end of the strings that contain the addresses 
		so that the 'extrair_ip_arp' function can extract and convert the ips correctly*/
		c = '.';
		strncat (ip_arp_src,	&c,1);
		strncat (ip_arp_dst,	&c,1);
		
		/*extract the ip in int format */
		for (int i = 0; i < 4; i ++) {
			extrair_ip_arp(ip_arp_src,	&i_ip_arp_src[i]);
			z++;
		}
		/*the variable z is accessed externally by the 'extrair_ip_arp' function to go through the string that contains the ip 
		address because it only reads until it finds the character '.' in the ip and then returns*/
		z = 0;
		for (int i = 0; i < 4; i ++) {
			extrair_ip_arp(ip_arp_dst,	&i_ip_arp_dst[i]);
		}
}		/*end of temporary variables*/
		
		/*struct ifreq*/
		struct ifreq device;
		/*create link header struct*/
		struct sockaddr_ll arp_link; 
		tam = make_arp(/*struct sockaddr_all and ifreq*/
				&arp_link,
				&device,
				datagrama,
				/*ethernet fram*/
				 &i_mac_eth_src[0],
				 &i_mac_eth_dst[0],
				 i_p_type_eth,
				 &soc,
				/*arp frame*/
				i_h_type_arp,
				i_p_type_arp,
				i_h_size_arp,
				i_p_size_arp,
				i_op_code,
				&i_mac_arp_src[0],
				&i_ip_arp_src[0],
				&i_mac_arp_dst [0],
				&i_ip_arp_dst[0],
				0x0806,
				interface_number);
	/*send arp*/	
	while (1) {

	retorno =  sendto (soc,	datagrama, tam, 0, (struct sockaddr*)&arp_link, (sizeof(arp_link)));
	if (retorno == -1) {
		TXT(ERROR,1,1);
		TXT(ERROR,3,0);	
		printf(": %i\n",errno);
	}
	else {
		TXT(ALERT,6,0);		
		printf(": %i\n",retorno);
		sleep (1);
	}
		quant  --;
	} /*end while send*/
		
}
	/*close socket and exit*/
	exit(0);
}


/*functions code*/
void proc_args (int valor, 
		char* argumentos [], 
		char *diretorio, 
		char* net_ip_main, 
		char *ip_src_main, 
		char *ip_dst_main, 
		char *dados_main){

	size_t i = 1;
	while (i!=valor){
	if ((strcmp (argumentos[i],"-c")==0)){quant	 = atoi(argumentos[i+1]);}
	if ((strcmp (argumentos[i],"-t")==0)){tempo  	 = atoi(argumentos[i+1]);}
	if ((strcmp (argumentos[i],"-s")==0)){ip_src_arg = argumentos[i+1]; src_set = 1;}
	if ((strcmp (argumentos[i],"-d")==0)){ip_dst_arg = argumentos[i+1]; dst_set = 1;}
	if ((strcmp (argumentos[i],"-D")==0)){tcp_data   = argumentos[i+1]; data_set = 1;}
	if ((strcmp (argumentos[i],"-R")==0)){	create_ipv4(diretorio); 
						create_tcp(diretorio); 
						create_udp(diretorio); 
						create_arp(diretorio); 
						exit (0); }	

	if ((strcmp (argumentos[i],"-r")==0)){ip_rand = 1; net_ip = argumentos[i+1]; p_to_net_bits = argumentos[i+2]; flood = 0;}
	if ((strcmp (argumentos[i],"-U")==0)){ protocol_ = 17; }
	if ((strcmp (argumentos[i],"-I")==0)){ protocol_ = 4;  }
	if ((strcmp (argumentos[i],"-T")==0)){ protocol_ = 6;  }
	if ((strcmp (argumentos[i],"-F")==0)){ flood = 1;  }
	if ((strcmp (argumentos[i],"-A")==0)){ 
				
				arp_set = 1; 
				if (argumentos [i+1] == NULL)  {
					TXT(TUTORIAL,9,1);
					TXT(TUTORIAL,10,1);
					exit (0);
				}
				else {
					interface_number = atoi (argumentos[i+1]);
				}
				
		
	}
	if ((strcmp (argumentos[i],"-fk")==0)){ 			
		
		if (argumentos [i+1] == NULL) {
			TXT(TUTORIAL,11,1);
			exit (0);
		}
		
		fake_data = atoi (argumentos[i+1]); 
		fk_data_set = 1; 
		protocol_   = 4;
		memset(dados_main,0,sizeof(dados_main));
	}

	i++;
}  /*end while*/

	if (arp_set == 1) {
		operation = 10;	
	}
	/*if rand ip is activade*/
	else if (ip_rand == 1) {
	       	src_set = 0;
		ouvir = 0;
		memset(ip_src_main,	0,sizeof(ip_src_main));

		if (net_ip        == NULL) { TXT(TUTORIAL,12,1);	exit(0); }
		if (p_to_net_bits == NULL) { TXT(TUTORIAL,13,1);	exit(0); }
		
		net_bits = atoi (p_to_net_bits);
		strcpy(net_ip_main,net_ip);

		switch (net_bits) {
				case 24:
					quant_host = 1;
			      		break;
				case 16:
					quant_host = 2;
					break;
				case 8:
					quant_host = 3;
					break;
				default:
				TXT(TUTORIAL,0,1);	
				TXT(TUTORIAL,1,1);
				TXT(TUTORIAL,2,1);	
				TXT(TUTORIAL,3,1);
				exit (0);
}	/*end switch*/
	
	/*if nothing target target was put for the user*/
		if (ip_dst_arg == NULL) { TXT(TUTORIAL,4,1);	exit(0); }
		else {
		       	strcpy (ip_dst_main,ip_dst_arg);
			operation = 0 + 3;
		}

}/*end else if rand ip*/

	/*Defualt protocol is TCP*/
	if (protocol_ == 0) {protocol_ = 6;}

	/*Limitis of program*/
	/*if packets to send is > of 30000*/
	if (quant > 30000 )  {
		TXT(ALERT,5,1);
		exit (0);
	}

	/*if ip rand not set*/

	if (arp_set == 0) { 
	if (ip_rand == 0 ){
		/*if not source ip is set*/
		if (src_set == 0) {
			TXT(TUTORIAL,6,1);
			exit (0);
			}
		else 	{
			strcpy (ip_src_main,ip_src_arg);
		       	operation = 1;
			}
		/*if not dest ip was set*/
		if (dst_set == 0) {
			TXT(TUTORIAL,7,1);
			exit (0);
			}
		else 	{
			strcpy (ip_dst_main,ip_dst_arg);
			operation = operation + 1;
			}
		/*if data was set*/
		if (data_set == 1) {
			if (tcp_data == NULL) {
				TXT(TUTORIAL,8,1);
				exit (0);
				}
			else 	{
				strcpy (dados_main,tcp_data);
				}	
		}
}}}
/* -----------------------------------------------------------------------------------------------------*/

void guide () {
TXT(TUTORIAL,	14,	0);	
TXT(TUTORIAL,	15,	0);	
TXT(TUTORIAL,	16,	0);	
TXT(TUTORIAL,	17,	0);	
TXT(TUTORIAL,	18,	0);	
TXT(TUTORIAL,	19,	0);	
TXT(TUTORIAL,	20,	0);	
TXT(TUTORIAL,	21,	0);	
TXT(TUTORIAL,	22,	0);	
TXT(TUTORIAL,	23,	0);	
TXT(TUTORIAL,	24,	0);	
TXT(TUTORIAL,	25,	0);	
TXT(TUTORIAL,	26,	0);	
TXT(TUTORIAL,	27,	0);	
}

void TXT (int code, int msg, int new_line) {
	switch (code)	 {
		
		case 0:
		if (new_line == 1) printf("%s\n",msg_error[msg]);
		else printf("%s",msg_error[msg]);

		break;

		case 1: 
		if (new_line == 1) printf("%s\n",msg_alert[msg]);
		else printf("%s",msg_alert[msg]);

		break;
	
		case 2: 
		if (new_line == 1 )printf("%s\n",msg_tutorial[msg]);
		else printf("%s",msg_tutorial[msg]);

		break;
		
		default:
		printf("Erro na lingaguem - Erro in language");
		exit(-1);
		}
}

