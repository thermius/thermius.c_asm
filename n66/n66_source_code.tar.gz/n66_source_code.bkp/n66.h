#include <stdint.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>	
void host_rand(char*);
void get_home_n66(char*);
void create_ipv4(char*);
void create_arp(char*);
void create_tcp(char*);
void create_udp (char*);

void read_ipv4(char *,size_t* ,size_t* ,size_t *,size_t* , size_t*);
void read_tcp (char *,size_t *,size_t *,size_t *,size_t *,size_t *,size_t *,size_t *, size_t *,size_t *,size_t *,size_t *,size_t *,size_t *,size_t *);
void read_udp (char*,size_t*, size_t*, size_t* );
void read_arp (char*,char*,char*,char*,char*,char*,char*,char*,char*,char*,char*,char*,char*);

void remove_n (char*);
void get_value(char*,char*);
int ip_check(char *);
uint16_t checksum_ip(void*,size_t);
void ip_aleatorio(size_t, char*, char*);
void ouvir_resposta(char*,char*);
void addr_in (struct sockaddr_in *,char []);
int opt_soc (int*);
void extrair(char*, int*);
void extrair_ip_arp(char*, int*);
int make_arp (struct sockaddr_ll*,struct ifreq*,char*,int*,int*,int,int*,int,int,int,int,int,int*,int*,int*,int*,int,int);
int make_ipv4 (char*, size_t, size_t, size_t, size_t, size_t, size_t, size_t, size_t, char*, char*);
void make_tcp (char*, size_t, size_t, size_t, size_t, size_t, size_t, size_t, size_t, size_t, size_t, size_t , size_t, size_t, size_t ,char*,char*,char[], /*ipv4*/size_t, size_t, size_t, size_t , size_t, size_t, size_t ,size_t );
int make_udp (char*, size_t, size_t, size_t,size_t,size_t,size_t,size_t,size_t,char*,char*,size_t,size_t,size_t);

