To compile:
1 - Grant execute permission to the file 'compile.sh'

2 - Run the script.

3 - n66 will be compiled in English by default but you can change the language.

-----------------------------------------------------------------------
 
Change language:

1 - Open the lang.c file

2 - edit the LANG definition for your language code if it is available.

3 - Run the compile.sh script

-----------------------------------------------------------------------

Tip: 

You can translate n66 into any language by following these steps:
Requirements: Basic knowledge of C language

1 - Open the lang.c file

2 - Translate the text into your language and paste it into the template left.

3 - Set your language code

4 - Run the compile.sh script

----------------------------

Support the project:

1 - Ideas, Code, Bugs etc in telegram group: https://t.me/+82JAyPcrHPk3YjUx
2 - Cryptocurrency / payment:
	SOLANA	:	ETtZwU7hiRu3zBwQh1tYtq6v2H4H2CKFkikPsHHusjfY
	ETH	:	0x4233139626D142b402EEbD839698E9f21cD44933
	paypal	:	thermius.arch@gmail.com




