#include <stdlib.h>
#include <stdio.h>

extern char *msg_alert[];		/*messagens about alerts*/
extern char *msg_error[];		/*massagens about erros*/
extern char *msg_tutorial[];		/*messagebs abaout tutorial an tips*/
