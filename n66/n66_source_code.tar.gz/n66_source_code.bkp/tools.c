#include "lang.h"
#include <stdio.h>
#include <sys/ioctl.h>       
#include <net/if.h>
#include <linux/if_packet.h>
#include <net/ethernet.h>
#include <stdlib.h>
#include <string.h>
#include "n66.h"
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <arpa/inet.h> 
#include <stdint.h>
#include <unistd.h>
#include <time.h>
#include <netinet/udp.h>
#include <ctype.h>

#define ERROR 0
#define ALERT 1
#define TUTORIAL 2

/*to print the messagebs of progam in multilangs*/
extern void TXT (int code,  int msg, int new_line);

/*socket opt*/
int opt_soc (int *soc)  {

	size_t op, *p_op;	
	op = 1;
	p_op = &op;
	setsockopt (*soc, IPPROTO_IP, IP_HDRINCL, p_op , sizeof(size_t));

}
/*resolv sockaddr_in*/
void addr_in (struct sockaddr_in *my, char ip_destino[]) {
	my->sin_family = AF_INET;
	my->sin_addr.s_addr = inet_addr (ip_destino);
}

/*make udp packet*/
int make_udp (	/*ipv4*/
		char *datagrama,
		size_t ihl_,
		size_t version_,
		size_t tos_,
		size_t id_,
		size_t frag_,
		size_t ttl_,
		size_t protocol_,
		size_t check_,
		char *ip_origem,
		char *ip_destino,
		/*udp*/
		size_t source_,
		size_t dest_,
		size_t check_udp) {

	struct	iphdr *iph = (struct iphdr*) datagrama;
	make_ipv4 (	datagrama,
			ihl_,
 			version_,
			tos_,
			id_,
			frag_,
			ttl_,
			protocol_,
	 		check_,
			ip_origem,
			ip_destino);

	struct udphdr *udp = (struct udphdr*) (datagrama + sizeof(struct iphdr));
	
		udp->source = htons (source_);
		udp->dest   = htons (dest_);
		udp->check  = check_udp;
		udp->len    = htons(8);
	
	return (	sizeof(struct iphdr)	+ 	sizeof(struct udphdr)	);

}
/*make tcp packet*/
void make_tcp (	char *datagrama,
		size_t source_,
		size_t dest_,
		size_t seq_,
		size_t ack_seq_,
		size_t doff_,
		size_t fin_,
		size_t syn_,
		size_t rst_,
		size_t psh_,
		size_t ack_,
		size_t urg_,
		size_t window_,
		size_t check_tcp_,
		size_t urg_ptr_,
		char *ip_destino,
		char *ip_origem,
		char dados_main[],
		/*ipv4 variables*/
		size_t ihl_,
		size_t version_,
		size_t tos_,
		size_t id_,
		size_t frag_,
		size_t ttl_,
		size_t protocol_,
		size_t check_
		) {

	char *p_data;
	extern size_t tam_datagrama;
	struct iphdr *iph = (struct iphdr*)datagrama;
	struct tcphdr *tcp  = (struct tcphdr*)	(datagrama + sizeof(struct iphdr)) ;


	tam_datagrama = make_ipv4 (datagrama,
			5,
			4,
			tos_,
			id_,
			frag_,
			ttl_,
			protocol_,
			check_,
			ip_origem,
			ip_destino);


	tcp->source 	= htons (source_);
	tcp->dest 	= htons (dest_);
	tcp->seq 	= htonl(seq_);
	tcp->ack_seq 	= htonl(ack_seq_);
	tcp->doff 	= doff_;
	tcp->fin 	= fin_;
	tcp->syn 	= syn_;
	tcp->rst 	= rst_;
	tcp->psh 	= psh_;
	tcp->ack	= ack_;
	tcp->urg 	= urg_;
	tcp->window 	= htons (window_);
	tcp->check 	= check_tcp_;
	tcp->urg_ptr	= urg_ptr_;

	if (check_tcp_ == 0 ) {

		size_t tam_tcp;
		char *tcp_datagrama;
		
		struct	  tcp_verificacao {
		u_int32_t source_address;
		u_int32_t dest_address;
		u_int8_t  placeholder;
		u_int8_t  protocol;
		u_int16_t tcp_length;
		} stcp;

		stcp.source_address 	= inet_addr (ip_origem);
		stcp.dest_address 	= inet_addr (ip_destino);
		stcp.placeholder 	= 0;
		stcp.protocol 		= IPPROTO_TCP;
		stcp.tcp_length 	= htons (sizeof(struct tcphdr) + strlen(dados_main));
		tam_tcp      = sizeof (struct tcp_verificacao)	+	sizeof (struct tcphdr)	+	strlen (dados_main);
		tcp_datagrama = malloc(tam_tcp);

		memset (tcp_datagrama,0,tam_tcp);
		memcpy (tcp_datagrama,(char*)&stcp,sizeof(struct tcp_verificacao));
		memcpy (tcp_datagrama + sizeof(struct tcp_verificacao),tcp,sizeof(struct tcphdr) + strlen (dados_main));
		tcp->check = checksum_ip(tcp_datagrama,tam_tcp);
		} /*end checksuum tcp*/
}

void remove_n (char *str) {
	int i = 0; 

	while (str [i] != '\0') {
		if (str [i] == '\n') {
			str [i] = '\0';
//			str [i + 1] = 0;
		}
	i++;
	}
}
/*extract IPs from arp file*/
void extrair_ip_arp (char *str,int *valores){

	extern int z;

	char *p;
	if (str [z] == '.') {
		z ++;
		p = str + z;
	}
	else { 
		p = &str[z];
	}

	char number [5];
	int x = 0;
	int count = 0;
	int *p_valores;
	int intervalo;
	memset (number,0,5);
	
	while (str [z] != '.') {
		strncat (number,p,1);
		p++;
		z++;
	}
		if (str [z] == '.') {
			*valores = atoi (number);
			memset (number,0,sizeof(number));
			return;
		}

}
/*extrac the hexcecimal string to number in arp packet*/
void extrair (char *str, int *p_valores) {

	char *p;
	char *p2;
	p = str;
	int i = 0;
	int control_p;

	while (str [i] != '\0') {
		if (str [i] == ':') {
			p2 = (str + i);
			*p_valores = strtol (p,0,16);
			p_valores ++;
			control_p ++;
			p = p2 + 1;
} 
		i++;
}
}
/*make eth datagrama whit arp packet*/
int make_arp (	struct sockaddr_ll *interface,
		struct ifreq *netdevice,
		char *datagrama,
		/*ethernet frame*/
		int *mac_eth_src,
		int *mac_eth_dst, 
		int eth_p_type,
		/*number of device, and socket descriptor*/
		int *socket_,
		/*arp frame*/
		int h_type,
		int p_type,
		int h_size,
		int p_size,
		int op_code,
		int *mac_arp_src,
		int *ip_arp_src ,
		int *mac_arp_dst,
		int *ip_arp_dst,
		int protocol_link,
		int number_device) { 

		int r_ioctl;
		int tam;
	
	struct arp_packet {
	/*arp frame*/
	uint16_t htype;
	uint16_t ptype;
  	uint8_t hlen;
  	uint8_t plen;
 	uint16_t opcode;
  	uint8_t sender_mac[6];
	uint8_t sender_ip[4];
  	uint8_t target_mac[6];
	uint8_t target_ip[4];

	};

	/*frame ether*/
	struct ether_header *eth = (struct ether_header*) datagrama;
	
	for (int i = 0; i < 6; i ++) { eth->ether_dhost [i] = mac_eth_dst [i]; } 	/*mac address destination*/
	for (int i = 0; i < 6; i ++) { eth->ether_shost [i] = mac_eth_src [i]; }	/*mac address origin*/
	
	/*protocol ethernet */
	eth->ether_type = htons (eth_p_type);

	/*frame arp*/
	struct arp_packet *arp =  (struct arp_packet*) (datagrama + sizeof(struct ether_header));

	arp->htype	= htons(h_type);
	arp->ptype	= htons(p_type);
	arp->hlen	= h_size;
	arp->plen	= p_size;
	arp->opcode	= htons(op_code);

	for (int  i = 0; i < 6; i ++) { arp->sender_mac [i] 	= mac_arp_src [i];  }	/*sender mac address*/
	for (int  i = 0; i < 6; i ++) { arp->target_mac [i] 	= mac_arp_dst [i];  }	/*target mac address*/
	for (int  i = 0; i < 4; i ++) { arp->sender_ip  [i] 	= ip_arp_src  [i];  }	/*ip sender*/
	for (int  i = 0; i < 4; i ++) { arp->target_ip  [i] 	= ip_arp_dst  [i];  }	/*ip target*/
	
	/* get interface name by number*/
	netdevice->ifr_ifindex = number_device;

	/*test if interface is valid*/
	r_ioctl = ioctl (*socket_,SIOCGIFNAME,netdevice);
	if ( r_ioctl != 0) {
		TXT(ERROR,4,1);
		exit (0);
	}
	
	/*filling physical layer. It is not necessary to fill in all the members of the structs*/
	interface->sll_family 	= AF_PACKET;			/*type of packet */
	interface->sll_protocol = htons (eth_p_type); 		/*protocolo da camada fisica (ARP in this case defined in the main)*/
	interface->sll_ifindex 	= netdevice->ifr_ifindex;	/*number interface*/
	interface->sll_hatype 	= htons(1);			/*type of hardware arp*/
	interface->sll_halen 	= 6;				/*mac lenght*/

	tam = sizeof(struct arp_packet)	;
	tam = tam + sizeof(struct ether_header);
	return tam;
}
/*make ipv4 datagram*/
int make_ipv4 (	char *datagrama,
		size_t ihl_,
		size_t version_,
		size_t tos_,
		size_t id_,
		size_t frag_,
		size_t ttl_,
		size_t protocol_,
		size_t check_,
		char *ip_origem,
		char *ip_destino) {

		extern size_t fake_data;

		size_t tam_to_check;
		struct iphdr *ip = (struct iphdr*)datagrama;
		ip->ihl 	= ihl_;
		ip->version	= 4;
		ip->tos 	= tos_;
		ip->id 		= htons (id_);
		ip->ttl 	= ttl_;
		ip->protocol 	= protocol_;
		ip->saddr 	= inet_addr (ip_origem);
		ip->daddr	= inet_addr (ip_destino);
		ip->check 	= check_;
		ip->frag_off    = frag_;


		if (check_ == 0) {	
			switch (protocol_) {

			case 6:
			tam_to_check = sizeof(struct iphdr) + sizeof (struct tcphdr);
			checksum_ip ((void*)datagrama,tam_to_check);
			ip->tot_len = tam_to_check;
			break;

			case 4:
			tam_to_check = sizeof(struct iphdr) + fake_data;
			checksum_ip ((void*)datagrama,tam_to_check);
			ip->tot_len = tam_to_check;
			break;

			case 17:
			tam_to_check = sizeof(struct iphdr) + sizeof(struct udphdr);
			checksum_ip ((void*)datagrama,tam_to_check);
			ip->tot_len = tam_to_check;
			break;

			} /*end switch case whit checksum set*/

		}

		else  {	
			switch (protocol_) {

			case 6:
			tam_to_check = sizeof(struct iphdr) + sizeof (struct tcphdr);
			ip->tot_len = tam_to_check;
			break;

			case 4:
			tam_to_check = sizeof(struct iphdr) + fake_data;
			ip->tot_len = tam_to_check;
			break;

			case 17:
			tam_to_check = sizeof(struct iphdr) + sizeof(struct udphdr);
			ip->tot_len = tam_to_check;
			break;

			} /*end switch case with checksum not set*/

		}
		


		return (ip->tot_len);
}

/*concat IPs rands*/
void ip_aleatorio (size_t quant_host, char *net_ip_main, char *ip_alvo) {
	char host_gerated[5];
	char ch = '.';
	char aux_rede[17];
	char **p_net_ip;
	p_net_ip = &net_ip_main;
	strcpy(aux_rede,net_ip_main);

/*1 host */
	if (quant_host == 1) {
			host_rand (host_gerated);
			strcat(net_ip_main,host_gerated);
			bzero(&host_gerated,sizeof(host_gerated));
			// #GET FINAL IP
			strcpy (ip_alvo,net_ip_main);
			bzero(net_ip_main,sizeof(net_ip_main));
			strcpy(net_ip_main,aux_rede);
			} //END quant_host 1 
	
/*2 host*/
	if (quant_host == 2) {
			host_rand (host_gerated);
			strcat(net_ip_main,host_gerated);
			bzero(host_gerated,sizeof(host_gerated));
			strncat(net_ip_main,&ch,1);

			host_rand(host_gerated);
			strcat(net_ip_main,host_gerated);
			bzero(host_gerated,sizeof(host_gerated));
			// #GET FINAL IP
			strcpy(ip_alvo,net_ip_main);
			bzero(net_ip_main,sizeof(net_ip_main));
			strcat(net_ip_main,aux_rede);
			}// #END quant_host 2
	
/*3 host*/
	if (quant_host == 3) {
			host_rand (host_gerated);
			strcat(net_ip_main,host_gerated);
			bzero(host_gerated,sizeof(host_gerated));
			strncat(net_ip_main,&ch,1);

			host_rand(host_gerated);
			strcat(net_ip_main,host_gerated);
			strncat(net_ip_main,&ch,1);
			bzero(host_gerated,sizeof(host_gerated));

			host_rand(host_gerated);
			strcat(net_ip_main,host_gerated);
			bzero(host_gerated,sizeof(host_gerated));
			// #GET FINAL IP
			strcpy(ip_alvo,net_ip_main);
			bzero(net_ip_main,sizeof(net_ip_main));
			strcat(net_ip_main,aux_rede);	
		}// #END quant_host 3	
	

}
/*this function read the arp from the = sign*/
void get_value_arp (char *ler, char* c_lido,int tam_read) {
	size_t i,j;
	char *p;
	p = ler;
	
	for (i = 0; i < sizeof(ler); i++){
		if ( ler[i] == '=') {
 		memcpy(c_lido,ler+i+1	,tam_read);
		}}
}
/*read arp file*/ 
void read_arp (	char *diretorio,
		/*ethernet*/
		char *mac_eth_src,
		char *mac_eth_dst,
		char *ptype_eth,
		/*arp*/
		char *htype,
		char *ptype,
		char *h_len,
		char *p_len,
		char *op_code,
		char *mac_arp_src,
		char *ip_src,
		char *mac_arp_dst,
		char *ip_dst) {

		char lido [50];
		char str_hlen [11];
		char str_plen [11];
		char str_opcode [11];

		FILE *file_arp = fopen(diretorio,"r");
		if (file_arp == NULL) {	
			TXT (ERROR,5,1); 
			printf("%s\n",diretorio); 
			fclose(file_arp); 
			exit(0);
			} 
		
		/*read ethernet filds */	
		fgets(lido,50,file_arp);
		get_value_arp (lido,	mac_eth_src,20);
		memset (lido,0,sizeof(lido));
	
		fgets(lido,50,file_arp);
		get_value_arp (lido,	mac_eth_dst,20);	
		memset (lido,0,sizeof(lido));
	
		fgets(lido,50,file_arp);
		get_value_arp (lido,	ptype_eth,15);	
		memset (lido,0,sizeof(lido));

		/*read arp fields*/
		fgets(lido,50,file_arp);
		get_value_arp (lido,	htype,15);
		memset (lido,0,sizeof(lido));
		
		fgets(lido,50,file_arp);
		get_value_arp (lido,	ptype,15);
		memset (lido,0,sizeof(lido));
		
		fgets(lido,50,file_arp);
		get_value_arp (lido,	h_len,15);
		memset (lido,0,sizeof(lido));
		
		fgets(lido,50,file_arp);
		get_value_arp (lido,	p_len,15);
		memset (lido,0,sizeof(lido));
	
		fgets(lido,50,file_arp);
		get_value_arp (lido,	op_code,15);
		memset (lido,0,sizeof(lido));
		
		fgets(lido,50,file_arp);
		get_value_arp (lido,	mac_arp_src,20);
		memset (lido,0,sizeof(lido));
		
		fgets(lido,50,file_arp);
		get_value_arp (lido,	ip_src,15);
		memset (lido,0,sizeof(lido));
		
		fgets(lido,50,file_arp);
		get_value_arp (lido,	mac_arp_dst,20);
		memset (lido,0,sizeof(lido));
	
		fgets(lido,50,file_arp);
		get_value_arp (lido,	ip_dst,15);
		memset (lido,0,sizeof(lido));
		fclose (file_arp);
		
}
/*read upd file*/
void read_udp ( char *diretorio,
		size_t *source,
		size_t *dest,
		size_t *check_udp) {

	char ler[30];
	char lido[5];
	FILE *file_udp = fopen(diretorio,"r");
	if (file_udp == NULL) {
		TXT(ERROR,6,1);
		printf("%s\n",diretorio); 
		fclose(file_udp); 
		exit(0);
		} 

		fgets(ler,30,file_udp);
		get_value(ler,lido);
		*source = atoi(lido);
		memset(ler,0,sizeof(ler));
		memset(lido,0,sizeof(lido));

		fgets(ler,30,file_udp);
		get_value(ler,lido);
		*dest =  atoi (lido);
		memset(ler,0,sizeof(ler));
		memset(lido,0,sizeof(lido));
	
		fgets(ler,30,file_udp);
		get_value(ler,lido);
		*check_udp =  atoi (lido);
		memset(ler,0,sizeof(ler));
		memset(lido,0,sizeof(lido));

}
/*Read tcp file*/
void read_tcp(	char *diretorio,
		size_t *source_,
		size_t *dest_,
		size_t *seq_,
		size_t *ack_seq_,
		size_t *doff_,
		size_t *fin_,
		size_t *syn_, 
		size_t *rst_,
		size_t *psh_,
		size_t *ack_,
		size_t *urg_,
		size_t *window_,
		size_t *check_tcp_,
		size_t *urg_ptr_) {
	
	char ler[30];
	char lido[5];
	FILE *file_tcp = fopen(diretorio,"r");
	if (file_tcp == NULL) {
		TXT(ERROR,7,1);
		printf("%s\n",diretorio); fclose(file_tcp); exit(0);} 

		fgets(ler,30,file_tcp);
		get_value(ler,lido);
		*source_ = atoi(lido);
		memset(ler,0,sizeof(ler));
		memset(lido,0,sizeof(lido));

		fgets(ler,30,file_tcp);
		get_value(ler,lido);
		*dest_ = atoi(lido);
		memset(ler,0,sizeof(ler));
		memset(lido,0,sizeof(lido));

		fgets(ler,30,file_tcp);
		get_value(ler,lido);
		*seq_ = atoi(lido);
		memset(ler,0,sizeof(ler));
		memset(lido,0,sizeof(lido));

		fgets(ler,30,file_tcp);
		get_value(ler,lido);
		*ack_seq_ = atoi(lido);
		memset(ler,0,sizeof(ler));
		memset(lido,0,sizeof(lido));

		fgets(ler,30,file_tcp);
		get_value(ler,lido);
		*doff_ = atoi(lido);
		memset(ler,0,sizeof(ler));
		memset(lido,0,sizeof(lido));

		fgets(ler,30,file_tcp);
		get_value(ler,lido);
		*fin_ = atoi(lido);
		memset(ler,0,sizeof(ler));
		memset(lido,0,sizeof(lido));

		fgets(ler,30,file_tcp);
		get_value(ler,lido);
		*syn_ = atoi(lido);
		memset(ler,0,sizeof(ler));
		memset(lido,0,sizeof(lido));

		fgets(ler,30,file_tcp);
		get_value(ler,lido);
		*rst_ = atoi(lido);
		memset(ler,0,sizeof(ler));
		memset(lido,0,sizeof(lido));

		fgets(ler,30,file_tcp);
		get_value(ler,lido);
		*psh_ = atoi(lido);
		memset(ler,0,sizeof(ler));
		memset(lido,0,sizeof(lido));

		fgets(ler,30,file_tcp);
		get_value(ler,lido);
		*ack_ = atoi(lido);
		memset(ler,0,sizeof(ler));
		memset(lido,0,sizeof(lido));

		fgets(ler,30,file_tcp);
		get_value(ler,lido);
		*urg_ = atoi(lido);
		memset(ler,0,sizeof(ler));
		memset(lido,0,sizeof(lido));

		fgets(ler,30,file_tcp);
		get_value(ler,lido);
		*window_ = atoi(lido);
		memset(ler,0,sizeof(ler));
		memset(lido,0,sizeof(lido));

		fgets(ler,30,file_tcp);
		get_value(ler,lido);
		*check_tcp_ = atoi(lido);
		memset(ler,0,sizeof(ler));
		memset(lido,0,sizeof(lido));

		fgets(ler,30,file_tcp);
		get_value(ler,lido);
		*urg_ptr_ = atoi(lido);
		memset(ler,0,sizeof(ler));
		memset(lido,0,sizeof(lido));
		fclose (file_tcp);

}

/*read ipv4 file*/
void read_ipv4(char *diretorio,size_t *tos_,size_t *id_,size_t *frag_,size_t *ttl_, size_t *check_) {

	char ler [30];
	char lido[5];
	FILE *file_ipv4 = fopen (diretorio,"r");
	if (file_ipv4 == NULL) {
		TXT(ERROR,8,1);
		printf("%s\n",diretorio); 
		fclose(file_ipv4); 
		exit(0);
		}
	//1.3 Get tos
		fgets(ler,30,file_ipv4);
		get_value(ler,lido);
		*tos_ = atoi(lido);
		memset(ler,0,sizeof(ler));
		memset(lido,0,sizeof(lido));
	//1.4 Get id
		fgets(ler,30,file_ipv4);
		get_value(ler,lido);
		*id_ = atoi(lido);
		memset(ler,0,sizeof(ler));
		memset(lido,0,sizeof(lido));
	//1.5 Get frag
		fgets(ler,30,file_ipv4);
		get_value(ler,lido);
		*frag_ = atoi(lido);
		memset(ler,0,sizeof(ler));
		memset(lido,0,sizeof(lido));
	//1.6 Get ttl
		fgets(ler,30,file_ipv4);
		get_value(ler,lido);
		*ttl_ = atoi(lido);
		memset(ler,0,sizeof(ler));
		memset(lido,0,sizeof(lido));
	//1.7 Get check
		fgets(ler,30,file_ipv4);
		get_value(ler,lido);
		*check_ = atoi(lido);
	
		memset(ler,0,sizeof(ler));
		memset(lido,0,sizeof(lido));
		memset(diretorio,0,sizeof(diretorio));
		fclose(file_ipv4);	
}

/*#Rand a host and convert to string*/
void host_rand (char *ip_char) {
	
	struct timespec milis;
	clock_gettime(CLOCK_MONOTONIC,&milis);

	srand((time_t)milis.tv_nsec);
	size_t host_rand;
	host_rand = rand () % 255;
	sprintf(ip_char,"%i",host_rand);
}
/*simple check ip algorith */
int check_ip (char *ip) {

 	short quant_ponto;
	short quant_digito;
	short tam;	
	short i;

	for (i = 0; i < 13; i++) {

		/*verify  quant digits*/
		if (isdigit (ip [i]) != 0 ) {
			quant_digito ++;
		}
		
		/*verify  quant .*/
		if (ip [i]  == '.') {
			quant_ponto++;
		}

	} /*end for*/

	/*result*/
	if (quant_ponto != 3 | quant_digito > 9 | (strlen (ip) > 13) )  {	
		TXT(ERROR,9,1);
		return 0;
	}
	else {
	
		return 1;
	}
}
/*get the name of user to get the directory /home/<user>/n66*/
void get_home_n66 (char *diretorio) {
	strcpy(diretorio,"/home/");
	char nome [15];
	char *buff;
	buff = getlogin();
	strcpy(nome,buff);
	strcat(diretorio,nome);
	strcat(diretorio,"/n66");
}

/*create the file udp*/
void create_udp(char *diretorio) {
	char aux[40];
	strcpy(aux,diretorio);
	strcat(diretorio,"/udp_header");

	FILE *file_udp = fopen (diretorio,"w");

	if (file_udp == NULL)  {
		TXT(ERROR,10,1);
		printf("%s\n",diretorio); 
		exit(0);
		}
	else {
		fprintf(file_udp,"src=1\n");	
		fprintf(file_udp,"dst=1\n");	
		fprintf(file_udp,"checksum=0\n");
		fprintf(file_udp,"\n O tamanho e calculado automaticamente pelo n66\n");	
		
		TXT(ALERT,10,1);
		printf("%s\n",diretorio);
		fclose (file_udp);
		memset(diretorio,0,sizeof(diretorio));
		strcpy(diretorio,aux);


	}
}

/*create the file arp*/
void create_arp (char *diretorio) {

	char aux [40];
	strcpy(aux,diretorio);
	strcat(diretorio,"/arp_header");
	
	FILE *file_arp = fopen (diretorio,"w");
	if (file_arp == NULL) { 
		TXT(ERROR,11,1);	
		printf ("%s\n",diretorio);
		exit(0);
	}
	
	fprintf(file_arp,"dhost=aa:aa:aa:aa:aa:aa\n");
	fprintf(file_arp,"shost=bb:bb:bb:bb:bb:bb\n");
	fprintf(file_arp,"type=0x806\n");

	fprintf(file_arp,"htype=1\n");
	fprintf(file_arp,"ptype=0x0800\n");
	fprintf(file_arp,"hlen=6\n");
	fprintf(file_arp,"plen=4\n");
	fprintf(file_arp,"opcode=2\n");
	fprintf(file_arp,"srcMac=00:00:00:00:00:00\n");
	fprintf(file_arp,"IPsrc=1.1.1.1\n");
	fprintf(file_arp,"dstMac=00:00:00:00:00:00\n");
	fprintf(file_arp,"IPdst=2.2.2.2\n");
	TXT(ALERT,7,1);
	printf("%s\n",diretorio);
	fclose(file_arp);
    
}
/*reate the file IPv4 */
void create_ipv4 (char *diretorio) {
	char aux [40];
	strcpy(aux,diretorio);
	strcat(diretorio,"/ipv4_header");
	
	FILE *file_ipv4 = fopen (diretorio,"w");
	if (file_ipv4 == NULL) { 
		TXT(ERROR,12,1);
		printf ("%s\n",diretorio);
		exit(0);
		}
	else  { 
		fprintf(file_ipv4,"tos=0\n");
		fprintf(file_ipv4,"id=1\n");
		fprintf(file_ipv4,"fragOff=0\n");
		fprintf(file_ipv4,"ttl=64\n");
		fprintf(file_ipv4,"check=0    #Atribua o valor 1 para desabilidar o checksum\n");
		fprintf(file_ipv4,"\n\n*Os IPs alvo e origem devem ser forcenidos via linha de comando e os demais campos são calculados pelo n66\n");

		TXT(ALERT,9,1);
		printf ("%s\n",diretorio); 
		fclose (file_ipv4);
		memset(diretorio,0,sizeof(diretorio));
		strcpy(diretorio,aux);

}}

/*create de tcp file*/
void create_tcp (char *diretorio) {
	char aux [40];
	strcpy(aux,diretorio);
	strcat(diretorio,"/tcp_header");

	FILE *file_tcp = fopen (diretorio,"w");
	if (file_tcp == NULL) { 
		TXT(ERROR,13,1);
		printf ("%s\n",diretorio);
		exit(0);
		}
	else  {

		fprintf(file_tcp,"source=1\n");
		fprintf(file_tcp,"dest=80\n");
		fprintf(file_tcp,"seq=1\n");
		fprintf(file_tcp,"ackSeq=111\n");
		fprintf(file_tcp,"doof=5\n");
		fprintf(file_tcp,"fin=0\n");
		fprintf(file_tcp,"syn=1\n");
		fprintf(file_tcp,"rst=0\n");
		fprintf(file_tcp,"psh=0\n");
		fprintf(file_tcp,"ack=0\n");
		fprintf(file_tcp,"urg=0\n");
		fprintf(file_tcp,"window=500\n");
		fprintf(file_tcp,"check=0			#Atribua o valor 1 para desabilitar o checksum\n");
		fprintf(file_tcp,"urgPtr=0\n");
		fclose (file_tcp);		
		TXT(ALERT,8,1);
		printf ("%s\n",diretorio);
		memset(diretorio,0,sizeof(diretorio));
		strcpy(diretorio,aux);
	}}
/*get the valoue after = from the files amd past in second parameter in string format*/
void get_value (char *ler, char* c_lido) {
	size_t i;

	for (i=0; i < sizeof(ler); i++){
		if (ler[i] == '=') {
 		memcpy(c_lido,ler+i+1,3);
		}}
}

/*checksum*/
uint16_t checksum_ip(void* vdata,size_t length) {
    char* data=(char*)vdata;
    uint32_t acc=0xffff;

    for (size_t i=0;i+1<length;i+=2) {
        uint16_t word;
        memcpy(&word,data+i,2);
        acc+=ntohs(word);
        if (acc>0xffff) {
            acc-=0xffff;
        }
    }

    if (length&1) {
        uint16_t word=0;
        memcpy(&word,data+length-1,1);
        acc+=ntohs(word);
        if (acc>0xffff) {
            acc-=0xffff;
        }
    }

    return htons(~acc);
   }
