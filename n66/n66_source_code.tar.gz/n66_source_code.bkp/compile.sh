#compile lang
gcc -c lang.c

#compile tools
gcc -c tools.c

#compile all
gcc main.c tools.o lang.o -o n66


