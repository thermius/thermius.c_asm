/*Autorh: Thermius */			//
/*Country: Brazil*/			//
/*Collaborators:*/			//
//////////////////////////////////////////
/*available language codes:
portugues-br	= 1
english 	= 0
*/

#define LAMG 0
#if (LANG == 1) 
 char *msg_alert[] = {
/*0*/	"Modo flood",

/*1*/	"Alvo",

/*2*/	"Enviado",

/*3*/	"IP aleatorio ativado",

/*4*/	"Enviado ao host",

/*5*/	"bytes enviados",

/*6*/	"ARP enviado",

/*7*/	"Arquivo ARP criado em",

/*8*/	"Arquivo TCP criado em",

/*9*/	"Arquivo IPv4 criado em",

/*10*/	"Arquivo UDP criado em",
	
};

char *msg_error[] = {
/*0*/	"Erro no socket. Verifique se esta logado como root",

/*1*/	"Erro no envio [sendto]",

/*2*/	"Erro na abertura do socket arp",

/*3*/	"Codigo de errno",

/*4*/	"Erro na interface de rede selecionada. Encerrando",

/*5*/	"Erro na abertura do arquivo arp_header",

/*6*/	"Erro na abertura do arquivo udp_header",

/*7*/	"Erro na abertura do arquivo tcp_header",

/*8*/	"Erro na abertura do arquivo ipv4_header",

/*9*/	"IP invalido",

/*10*/	"Erro na criacao do arquivo UDP em",

/*11*/ 	"Erro na criacao do arquivo arp em",

/*12*/	"Erro na criacao do arquivo IPv4 em",

/*13*/	"Erro na criacao do arquivo TCP em",



};

char *msg_tutorial[] = {
/*0*/	"Forneca os bits da rede em formato inteiro para criacao da quantidade correta de hosts aleatorio",

/*1*/	"24 - Cria 1 host aleatorio no intervalo de 0 ~ 255",

/*2*/	"16 - Cria 2 host aleatorio no intervalo de 0 ~ 25",

/*3*/	"8  - Cria 3 host aleatorio no intervalo de 0 ~ 255",

/*4*/	"Forncena um alvo com a  opcao -d",

/*5*/	"Nao e permitido enviar mais de 30000 pacotes ao alvo. Ative  modo flood com -F",

/*6*/	"Forneca um IP de origem",

/*7*/	"Forneca um IP alvo",

/*8*/	"Forneca os dados a serem enviados",

/*9*/   "Forneca o numero da interface de rede para enviar o arp",

/*10*/	"Use 'ip a' para listar todas as interfaces de rede e seus numeros",

/*11*/	"Forneca um numero inteiro para o uso de fake data",

/*12*/	"Forneca o IP da rede con o '.' para cricacao dos host da rede",

/*13*/	"Forneca os bits da rede para criar a quantidade correta de hosts",

/*simple guide to use*/	

/*14*/	"\t\t\t\t\t\tNetwork 66 - n66\n\n",

/*15*/	"Simples guia de uso\n\n",

/*16*/	"-c:	count       - Permite especificar a  quantiade de pacotes a serem enviados\n",

/*17*/	"-t:	time	    - Permite especificar o tempo de envio entre pacotes. Especifique 0 envio sem pausa\n",

/*18*/	"-r:	rand 	    - Permite ativar a geração de IPs de origem aleatorios para enviar ao alvo. Ao ativar rand, o modo flood e ativado aumaticamente\n",

/*19*/	"-s:	source	    - Permite especificar um endereço de origem para enviar o pacote (falsificar o ip)\n",

/*20*/	"-d:	destination - Permite especificar o alvo\n",

/*21*/	"-D:	Dados	    - Permite especificar os dados a serem enviados pelo TCP. Dados são lidos ate o caractere espaco ' '\n",

/*22*/	"-R:	Recreate    - Permite recriar os arquivos dos protocolos de  redes do n66\n",

/*23*/	"-U:	UDP packet  - Enviara pacotes UDP\n",

/*24*/	"-I:	IPv4 packet - Enviara pacotes IPv4\n",

/*25*/	"-A	ARP packet - Permite enviar pacotes ARP ao alvo\n",

/*26*/	"-fk	Fake_data   - Insere 0s ao final do datagrama. Infome a quantiade de 0 que eseja enviar para descobrir a MTU da rede\n",

/*27*/"-F	Flood	    - Ativa o modo flood\n",
	
};
#endif



/*Template for translations*/
#if (LANG == 0) 
 char *msg_alert[] = {
/*0*/	"Flood Mode",

/*1*/	"Target",

/*2*/	"Sent",

/*3*/	"Random IP enabled",

/*4*/	"Sent to host",

/*5*/	"bytes sent",

/*6*/	"ARP sent",

/*7*/	"ARP file created in",

/*8*/	"TCP file created in",

/*9*/	"IPv4 file created in",

/*10*/	"UDP file created in",
	
};

char *msg_error[] = {
/*0*/	"Socket error. Make sure you are logged in as root",

/*1*/	"Sending error [sendto]",

/*2*/	"Error opening arp socket",

/*3*/	"Error code",

/*4*/	"Error on the selected network interface. Shutting down",

/*5*/	"Error opening arp_header file",

/*6*/	"Error opening udp_header file",

/*7*/	"Error opening tcp_header file",

/*8*/	"Error opening ipv4_header file",

/*9*/	"Invalid IP",	

/*10*/	"Error creating the UDP file in",

/*11*/ 	"Error creating the ARP file in",

/*12*/	"Error creating the IPv4 file in",

/*13*/	"Error creating the TCP file in",



};

char *msg_tutorial[] = {
/*0*/	"Provide network bits in integer format for creating random hosts",

/*1*/	"24 - Creates 1 random host in the range 0 ~ 255",

/*2*/	"16 - Creates 2 random host in the range 0 ~ 255",

/*3*/	"8 - Creates 3 random host in the range 0 ~ 255",

/*4*/	"Provide a target with the -d option",

/*5*/	"It is not allowed to send more than 30k packets to the target. Activate flood mode with -F",

/*6*/	"Provide a source IP",

/*7*/	"Provide a target IP",

/*8*/	"Provides the data to be sent",

/*9*/   "Provides the network interface number to send the ARP",

/*10*/	"Use 'ip a ' to list all network interfaces and their numbers",

/*11*/	"Provide an internal number for the use of fake data",

/*12*/	"Provide the network IP with the '.' to create network hosts",

/*13*/	"Provides the network bits to create the correct number of hosts",

/*simple guide to use*/	

/*14*/	"\t\t\t\t\t\tNetwork 66 - n66\n\n",

/*15*/	"Simple usage guide\n\n",

/*16*/	"-c:	count       - Allows you to specify the number of packages to be sent\n",

/*17*/	"-t:	time	    - Allows you to specify the shipping time between packages. Specify 0 send without pause\n",

/*18*/	"-r:	rand 	    - Allows you to activate the generation of random source IPs to send to the target. When activating rand, flood mode is activated automatically\n",

/*19*/	"-s:	source	    - Allows you to specify a source address to send the packet (spoof the IP)\n",

/*20*/	"-d:	destination - Allows you to specify the target\n",

/*21*/	"-D:	Dados	    - Allows you to specify the data to be sent over TCP. Data is read up to the space character\n",

/*22*/	"-R:	Recreate    - Allows you to recreate the n66 network protocol files\n",

/*23*/	"-U:	UDP packet  - Will send UDP packets\n",

/*24*/	"-I:	IPv4 packet - Will send IPv4 packets\n",

/*25*/	"-A	ARP packet -  Will send ARP packets\n",

/*26*/	"-fk	Fake_data   - Inserts 0s at the end of the datagram. Enter the amount of 0 you want to send to find out the network MTU\n",

/*27*/"-F	Flood	    - Activate flood mode\n",
	
};
#endif


/*Template for translations*/
#if (LANG == 999) 
 char *msg_alert[] = {
/*0*/	"",

/*1*/	"",

/*2*/	"",

/*3*/	"",

/*4*/	"",

/*5*/	"",

/*6*/	"",

/*7*/	"",

/*8*/	"",

/*9*/	"",
	
};

char *msg_error[] = {
/*0*/	"",

/*1*/	"",

/*2*/	"",

/*3*/	"",

/*4*/	"",

/*5*/	"",

/*6*/	"",

/*7*/	"",

/*8*/	"",

/*9*/	"",

/*10*/	"",

/*11*/ 	"",

/*12*/	"",

/*13*/	"",



};

char *msg_tutorial[] = {
/*0*/	"",

/*1*/	"",

/*2*/	"",

/*3*/	"",

/*4*/	"",

/*5*/	"",

/*6*/	"",

/*7*/	"",

/*8*/	"",

/*9*/   "",

/*10*/	"",

/*11*/	"",

/*12*/	"",

/*13*/	"",

/*simple guide to use*/	

/*14*/	"\t\t\t\t\t\tNetwork 66 - n66\n\n",

/*15*/	"\n\n",

/*16*/	"-c:	count       - \n",

/*17*/	"-t:	time	    - \n",

/*18*/	"-r:	rand 	    - \n",

/*19*/	"-s:	source	    - \n",

/*20*/	"-d:	destination - \n",

/*21*/	"-D:	Dados	    - \n",

/*22*/	"-R:	Recreate    - \n",

/*23*/	"-U:	UDP packet  - \n",

/*24*/	"-I:	IPv4 packet - \n",

/*25*/	"-A	ARP packet -  \n",

/*26*/	"-fk	Fake_data   - \n",

/*27*/"-F	Flood	    - \n",
	
};
#endif

